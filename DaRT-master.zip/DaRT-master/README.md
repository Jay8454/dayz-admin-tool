# DaRT

### Description
DaRT (DayZ RCon Tool) is a graphical interface for the BattlEye RCon protocol.

It utilizes the [BattleNET](https://github.com/marceldev89/BattleNET) library by [marceldev89](https://github.com/marceldev89).

### Notes

If DaRT should crash the first time you build it just build it once more - looking into the problem.

I do not actively develop DaRT anymore. Feel free to fork DaRT though.
